$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CyclosFunctioanlTest.feature");
formatter.feature({
  "line": 1,
  "name": "This is to validate the functionalities of CyclosWebsite",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Validate whether payment is being made to existing user is successful",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@PayUser_DataTable"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Required website is launched also business user is able to loggin with the authorized credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Following are the payment details",
  "rows": [
    {
      "cells": [
        "User(quick search)",
        "Amount"
      ],
      "line": 7
    },
    {
      "cells": [
        "Nicola Tesla",
        "15"
      ],
      "line": 8
    },
    {
      "cells": [
        "Hotel Oasis",
        "20"
      ],
      "line": 9
    },
    {
      "cells": [
        "Henry George",
        "30"
      ],
      "line": 10
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "System is able to make the desired payment",
  "keyword": "Then "
});
formatter.match({
  "location": "PayUserDataTableTC1.required_website_is_launched_also_business_user_is_able_to_loggin_with_the_authorized_credentials()"
});
formatter.result({
  "duration": 8818831800,
  "status": "passed"
});
formatter.match({
  "location": "PayUserDataTableTC1.following_are_the_payment_details(DataTable)"
});
formatter.result({
  "duration": 3912161700,
  "status": "passed"
});
formatter.match({
  "location": "PayUserDataTableTC1.system_is_able_to_make_the_desired_payment()"
});
formatter.result({
  "duration": 38226700,
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d73.0.3683.75)\n  (Driver info: chromedriver\u003d73.0.3683.68 (47787ec04b6e38e22703e856e101e840b65afe72),platform\u003dWindows NT 10.0.17763 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.10.0\u0027, revision: \u0027176b4a9\u0027, time: \u00272018-03-02T19:03:16.397Z\u0027\nSystem info: host: \u0027TGS-DPC-2469\u0027, ip: \u0027192.168.81.92\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_211\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 73.0.3683.68 (47787ec04b6e3..., userDataDir: C:\\Users\\INDUCT~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:55232}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), rotatable: false, setWindowRect: true, strictFileInteractability: false, takesHeapSnapshot: true, takesScreenshot: true, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unexpectedAlertBehaviour: ignore, unhandledPromptBehavior: ignore, version: 73.0.3683.75, webStorageEnabled: true}\nSession ID: 7ae9a3b9ada08a3364f6bf119184d148\n*** Element info: {Using\u003dxpath, value\u003d//div[@class\u003d\u0027notificationText notificationText-singleLine\u0027]}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:160)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:601)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:371)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:473)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:363)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy15.getText(Unknown Source)\r\n\tat com.ObjectRepository.PayUserPageObject.paymentVerification(PayUserPageObject.java:99)\r\n\tat com.StepDefinTestCases.PayUserDataTableTC1.system_is_able_to_make_the_desired_payment(PayUserDataTableTC1.java:56)\r\n\tat ✽.Then System is able to make the desired payment(CyclosFunctioanlTest.feature:11)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "line": 16,
  "name": "Validate whether payment is being made to existing user is successful",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 15,
      "name": "@PayUser_ScenarioOutline"
    }
  ]
});
formatter.step({
  "line": 17,
  "name": "Website launched also business user is able to loggin with the authorized credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "Data details are User(quick search) \"\u003cUser(quick search)\u003e\"  Amount \"\u003cAmount\u003e\" system is able to make the payment",
  "keyword": "When "
});
formatter.examples({
  "line": 19,
  "name": "",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;",
  "rows": [
    {
      "cells": [
        "User(quick search)",
        "Amount"
      ],
      "line": 20,
      "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;;1"
    },
    {
      "cells": [
        "Nicola Tesla",
        "40"
      ],
      "line": 21,
      "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;;2"
    },
    {
      "cells": [
        "Hotel Oasis",
        "300"
      ],
      "line": 22,
      "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;;3"
    },
    {
      "cells": [
        "Henry George",
        "600"
      ],
      "line": 23,
      "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 21,
  "name": "Validate whether payment is being made to existing user is successful",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 15,
      "name": "@PayUser_ScenarioOutline"
    }
  ]
});
formatter.step({
  "line": 17,
  "name": "Website launched also business user is able to loggin with the authorized credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "Data details are User(quick search) \"Nicola Tesla\"  Amount \"40\" system is able to make the payment",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.match({
  "location": "PayUserScnOutlineTC2.website_launched_also_business_user_is_able_to_loggin_with_the_authorized_credentials()"
});
